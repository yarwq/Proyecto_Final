<?php
session_start();
if (!isset($_SESSION["user_id"])) {
    header("Location: login.html");
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Reglas del juego</title>
<link rel="stylesheet" href="menu.css">
</head>
<body>
<div class="container">
    <div class="logo-box">
        <img src="assets/logo.png" alt="logo">
    </div>
    <h1 class="bienvenido">Reglas del juego</h1>

    <div class="text">
En Draftosaurus, los jugadores tendrán que ir colocando dinosaurios en los distintos recintos para conseguir la máxima cantidad de puntos posible. Estas zonas, además de no puntuar igual, tienen una regla que hay que cumplir para que el parque siga en armonía. El juego consta de 2 rondas de juego divididas cada una de ellas en 6 turnos que se juegan exactamente igual. Antes de empezar en cada ronda, todos los jugadores sacarán de la bolsa sin mirar 6 dinosaurios que ocultarán en su mano al resto de jugadores.

Teniendo en cuenta todo esto, organizar nuestro zoológico de dinosaurios parece una tarea fácil ¿me equivoco? Pues sí, porque no lo es. No podremos colocar los 6 dinosaurios que hemos sacado de la bolsa. Tan solo nos quedaremos con uno de ellos y el resto los pasaremos al siguiente jugador. Y para rizar el rizo el jugador inicial, que cambiará en cada turno, será el encargado de lanzar el dado con el que se indicará una regla extra a cumplir durante el turno en curso. Ahora sí que parece un poco caótico el parque tan bonito que os habíais montado en vuestras cabecitas ¿verdad?
En primer lugar, el jugador inicial lanza el dado y los jugadores sabrán en qué recintos podrán colocar sus dinosaurios. Cuando cada jugador tenga claro qué dinosaurio de su mano quiere colocar en su parque, se revela el dinosaurio escogido y se coloca en el tablero de juego.
Hay que tener en cuenta dos apuntes. El jugador que tira el dado será el único que no está obligado a cumplir con la regla del dado, por lo que podrá colocar su dinosaurio donde quiera siempre que el resto de reglas del juego lo permitan. Por otro lado, en el caso de que algún jugador no pueda o quiera colocar un dinosaurio, podrá descartarlo en el río.

Cuando todos hayan colocado sus dinosaurios, los restantes se pasan al jugador de la izquierda, por lo que a todos también nos llegarán nuevos dinosaurios para seguir organizando el zoológico.
Una vez se hayan colocado 6 dinosaurios en cada tablero comienza la segunda ronda, donde los jugadores volverán a sacar de la bolsa 6 dinosaurios y jugarán como lo han hecho durante la primera ronda, pero manteniendo los dinosaurios colocados en sus tableros.

    </div>


    <a href="terminos.html" class="terms">Términos y condiciones</a>
</div>
</body>
</html>
